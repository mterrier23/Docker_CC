import os
import socket
entries = os.scandir('/home/data/')
length = 0
max_words = 0
max_file = ""
f = open("/home/output/result.txt", "w+")
for entry in entries:
	#f.write(entry.name + "\n")
	f.write(entry.name + " - ")
	file = open(entry)
	data = file.read()
	words = data.split()
	tmp_len = len(words)
	f.write(str(tmp_len) + " words\n")
	if tmp_len > max_words:
		max_file = entry.name
		max_words = tmp_len
	length = length + len(words)
hostname = socket.gethostname()
ip_address = socket.gethostbyname(hostname)
f.write("Total word count = " + str(length) + " words")
f.write("\nFile with max word count = " +  max_file)
f.write(f"\nIP Address: {ip_address}")
f.close()
f = open("/home/output/result.txt","r")
print(f.read())

